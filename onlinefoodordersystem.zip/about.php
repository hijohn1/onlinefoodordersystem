<?php
   session_start();
   include("admin/functions/connection.php");
?>

<html>
    <head>
    	<title>Food order system</title>
    	<link href="pages style/about.css"  rel="stylesheet" />
	</head>

	<body>
		
         <?php include("header.php"); ?>

         <div style="height: 7%;"></div>
		   <div id="aboutus">
		   	  <div id="content">
		   	  	 <div style="height: 5%"></div>
		          <h1>About Us</h1>
		          <br>
		          <div id="aboutuscontent1">Olive`s gourmet was found in 2009, and we are focused on bringing the most delicious food to your desk. Therefore, we are built by a group of innovative and passionate chefs to achieve this great goal. Every month, we add 2 or 3 new dishes on our menu. You always can taste latest food from Olive`s gourment.<br><br>What are you waiting for? Start choosing now!</div>
		      </div>
		   </div>
		   
	</body>
</html>