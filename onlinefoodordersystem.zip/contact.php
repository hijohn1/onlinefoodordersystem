<?php
   session_start();
   include("admin/functions/connection.php");

?>

<html>
    <head>
    	<title>Food order system</title>
    	<link href="pages style/contact.css"  rel="stylesheet" />
	</head>

	<body>
         <?php include("header.php"); ?>
         <div style="height:12%;"></div>
		   <div id="contactus"><br><br>
		   	<div id="content">Contact us</div>
		              	
		      <div id="address"><div id="addressposition">Address: <br>170 Grand st New York NY 11099<br><br>Phone:<br> 1-(212)-988-8902</div></div>
		      <div id="image"><img src="images/3.jpg" width="500px" height="400px"></div>
		     
		    </div>
		   
	</body>
</html>